#include <DHT.h>

const byte dhtPin = 13;       
#define DHTTYPE DHT11        

DHT dht(dhtPin, DHTTYPE); 

void setup() {  
  Serial.begin(115200);  
  dht.begin();   
  Serial.println("Memulai Sensor Lingkungan...");  
}

void loop() {  
  delay(2500); 

  float temp = dht.readTemperature();   
  float hum = dht.readHumidity();     

  if (isnan(temp) || isnan(hum)) {  
    Serial.println("Gagal membaca data dari sensor DHT!");  
    return; 
  }

  Serial.print("Suhu: ");  
  Serial.print(temp);  
  Serial.print(" Celcius | Kelembapan: ");  
  Serial.print(hum);  
  Serial.println(" %");  
}